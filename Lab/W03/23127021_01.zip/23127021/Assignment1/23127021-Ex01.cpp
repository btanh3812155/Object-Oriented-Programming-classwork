#include "fractionArray.cpp"

int main () {
    FractionArray testArray;
    

    return 0;
}